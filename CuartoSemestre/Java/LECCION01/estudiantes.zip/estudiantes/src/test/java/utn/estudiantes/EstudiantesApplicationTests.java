package utn.estudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudiantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
